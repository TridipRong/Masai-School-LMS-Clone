package com.masai.team4.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.masai.team4.entities.Role;


public interface RoleRepo extends JpaRepository<Role, Integer> {

}
