package com.masai.team4.exception;

public class LectureException extends Exception {

	public LectureException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LectureException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
