package com.masai.team4.exception;

public class InvalidTokenException extends Exception {

	public InvalidTokenException() {
		super();
		// TODO Auto-generated constructor stub
	}

}
