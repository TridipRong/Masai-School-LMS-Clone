package com.masai.team4.exception;

public class TokenExpiredException extends Exception {

	public TokenExpiredException() {
		super();
		// TODO Auto-generated constructor stub
	}

}
