package com.masai.team4.exception;

public class ApiException  extends RuntimeException{
	
	public ApiException() {
		// TODO Auto-generated constructor stub
		super();
	}

	public ApiException(String message) {
		super(message);
	 
	}
	
	

}
