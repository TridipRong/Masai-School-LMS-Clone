package com.masai.team4.constant;

public class Team4Constants {

}
