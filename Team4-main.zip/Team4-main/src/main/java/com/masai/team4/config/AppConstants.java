package com.masai.team4.config;

public class AppConstants {

	
	public static final Integer STUDENT_USER=502;
	public static final Integer ADMIN_USER=501;
	public static final String PAGE_NUMBER="1";
	public static final String PAGE_SIZE ="6";
	
}
