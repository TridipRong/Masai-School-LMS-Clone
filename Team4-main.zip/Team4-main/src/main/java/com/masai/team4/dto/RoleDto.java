package com.masai.team4.dto;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class RoleDto {
	private int id;
	private String name;
}
